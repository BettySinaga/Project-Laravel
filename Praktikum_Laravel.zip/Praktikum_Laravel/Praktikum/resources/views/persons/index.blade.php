	@extends('layouts.app')
	@extends('master')
	@section('content')
	<div class="row" style="margin-top: 10rem;">
		<div class="col-md-12">
			<center><h1>Client</h1></center>
		</div>
	</div>
	<div class="row">
	<form class="navbar-form navbar-left" role="search" method="get">
		<div class="input-group custom-search-form">
			<input type="text" name="search" class="form-control" placeholder="Search...">
			<span class="input-group-btn">
				<button type="submit" class="btn btn-default" style="background-color: grey; color: white;">
				search
				</button>
			</span>
		</div>

	</form>	
	   <table class="table table-responsive">
		<tr>
		  <th>No</th>
		  <th>image</th>
		  <th>Full names</th>
		  <th>Sex</th>
		  <th>Identity Card NR</th>
		  <th>Birth Date</th>
		  <th>Province</th>
		  <th>District</th>
		  <th>Sector</th>
		  <th>Cellar</th>
		  <th>Action</th>
		</tr>
		<a href="{{route('person.create')}}" class="btn btn-info pull-right">Create New Client</a>		
		<?php $id=1;?>
	@foreach($persons as $person)
		<tr>
		  <td>{{$id}}</td>
		  <td><img width="50" height="50" src="{{"image/".$person->image}}"></td>
		  <td>{{$person->fullnames}}</td>
		  <td>{{$person->sex}}</td>
		  <td>{{$person->identitycard}}</td>
		  <td>{{$person->birthdate}}</td>
		  <td>{{$person->province}}</td>
		  <td>{{$person->district}}</td>
		  <td>{{$person->sector}}</td>
		  <td>{{$person->cellar}}</td>
		  <td>
		  	<form class="" action="{{route('person.destroy', $person->id)}}" method="post">
		  	  <input type="hidden" name="_method" value="delete">
		  	  <input type="hidden" name="_token" value="{{csrf_token()}}">
		  	  <a href="{{route('person.edit', $person->id)}}" class="btn btn-primary">Edit</a>
		  	  <input type="submit" class="btn btn-danger" onclick="return confirm('Are you sure to delete this data?');" name="name" value="delete">
		  	</form>
		  </td>
		</tr>
		<?php $id++; ?>
		@endforeach
		</table>
	</div>
	@stop