@extends('layouts.app')
@extends('master')
	@section('content')
	<div class="row" style="margin-top: 10rem;">
		<div class="col-md-12">
			<center><h1>Insert Data Client</h1></center>
		</div>
	</div>
	<center>
	<div class="container">
	<div class="row">
		<form class="form1" action="{{route('person.store')}}" method="post">
		{{csrf_field()}}
		  <div class="form group{{ ($errors->has('image')) ? $errors->first('image') : '' }}">
		  <input type="file" name="image">
		  {!! $errors->first('image', '<p class="help-block">:message</p>') !!}
		  </div>	
		  <div class="form group{{ ($errors->has('fullnames')) ? $errors->first('fullnames') : '' }}">
		  <input type="text" name="fullnames" class="form-control" placeholder="Enter Fullname">
		  {!! $errors->first('fullnames', '<p class="help-block">:message</p>') !!}
		  </div>	
		  <div class="form group{{ ($errors->has('Sex')) ? $errors->first('Sex') : '' }}">
		  <input type="text" name="sex" class="form-control" placeholder="Enter Sex">
		  {!! $errors->first('sex', '<p class="help-block">:message</p>') !!}
		  </div>	
		  <div class="form group{{ ($errors->has('identitycard')) ? $errors->first('identitycard') : '' }}">
		  <input type="text" name="identitycard" class="form-control" placeholder="Enter Identity Card NR">
		  {!! $errors->first('identitycard', '<p class="help-block">:message</p>') !!}
		  </div>
		  <div class="form group{{ ($errors->has('birthdate')) ? $errors->first('birthdate') : '' }}">
		  <input type="text" name="birthdate" class="form-control" placeholder="Enter BirthDate">
		  {!! $errors->first('birthdate', '<p class="help-block">:message</p>') !!}
		  </div>	
		  <div class="form group{{ ($errors->has('province')) ? $errors->first('province') : '' }}">
		  <input type="text" name="province" class="form-control" placeholder="Enter Province">
		  {!! $errors->first('province', '<p class="help-block">:message</p>') !!}
		  </div>
		  <div class="form group{{ ($errors->has('district')) ? $errors->first('district') : '' }}">
		  <input type="text" name="district" class="form-control" placeholder="Enter District">
		  {!! $errors->first('district', '<p class="help-block">:message</p>') !!}
		  </div>
		  <div class="form group{{ ($errors->has('sector')) ? $errors->first('sector') : '' }}">
		  <input type="text" name="sector" class="form-control" placeholder="Enter Sector">
		  {!! $errors->first('sector', '<p class="help-block">:message</p>') !!}
		  </div>
		  <div class="form group{{ ($errors->has('cellar')) ? $errors->first('cellar') : '' }}">
		  <input type="text" name="cellar" class="form-control" placeholder="Enter Cellar">
		  {!! $errors->first('cellar', '<p class="help-block">:message</p>') !!}
		  </div>		  		  		  	
		  	  <input type="submit" class="button" value="save">  		  	  	  
			</form>
		</div>
		</div>
	</center>
	@stop