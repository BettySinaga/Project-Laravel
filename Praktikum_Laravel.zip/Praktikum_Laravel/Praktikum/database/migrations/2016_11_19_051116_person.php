<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class Person extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Person', function(Blueprint $table){
            $table->increments('id');
            $table->string('image');
            $table->string('fullnames');
            $table->string('sex');
            $table->string('identitycard');
            $table->string('birthdate');
            $table->string('province');
            $table->string('district');
            $table->string('sector');
            $table->string('cellar');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('Person');
    }
}
