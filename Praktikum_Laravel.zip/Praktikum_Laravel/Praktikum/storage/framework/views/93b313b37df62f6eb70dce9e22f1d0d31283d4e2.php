	<?php $__env->startSection('content'); ?>
	<div class="row" style="margin-top: 10rem;">
		<div class="col-md-12">
			<center><h1>Insert Data Client</h1></center>
		</div>
	</div>
	<center>
	<div class="container">
	<div class="row">
		<form class="form1" action="<?php echo e(route('person.store')); ?>" method="post">
		<?php echo e(csrf_field()); ?>

		  <div class="form group<?php echo e(($errors->has('image')) ? $errors->first('image') : ''); ?>">
		  <input type="file" name="image">
		  <?php echo $errors->first('image', '<p class="help-block">:message</p>'); ?>

		  </div>	
		  <div class="form group<?php echo e(($errors->has('fullnames')) ? $errors->first('fullnames') : ''); ?>">
		  <input type="text" name="fullnames" class="form-control" placeholder="Enter Fullname">
		  <?php echo $errors->first('fullnames', '<p class="help-block">:message</p>'); ?>

		  </div>	
		  <div class="form group<?php echo e(($errors->has('Sex')) ? $errors->first('Sex') : ''); ?>">
		  <input type="text" name="sex" class="form-control" placeholder="Enter Sex">
		  <?php echo $errors->first('sex', '<p class="help-block">:message</p>'); ?>

		  </div>	
		  <div class="form group<?php echo e(($errors->has('identitycard')) ? $errors->first('identitycard') : ''); ?>">
		  <input type="text" name="identitycard" class="form-control" placeholder="Enter Identity Card NR">
		  <?php echo $errors->first('identitycard', '<p class="help-block">:message</p>'); ?>

		  </div>
		  <div class="form group<?php echo e(($errors->has('birthdate')) ? $errors->first('birthdate') : ''); ?>">
		  <input type="text" name="birthdate" class="form-control" placeholder="Enter BirthDate">
		  <?php echo $errors->first('birthdate', '<p class="help-block">:message</p>'); ?>

		  </div>	
		  <div class="form group<?php echo e(($errors->has('province')) ? $errors->first('province') : ''); ?>">
		  <input type="text" name="province" class="form-control" placeholder="Enter Province">
		  <?php echo $errors->first('province', '<p class="help-block">:message</p>'); ?>

		  </div>
		  <div class="form group<?php echo e(($errors->has('district')) ? $errors->first('district') : ''); ?>">
		  <input type="text" name="district" class="form-control" placeholder="Enter District">
		  <?php echo $errors->first('district', '<p class="help-block">:message</p>'); ?>

		  </div>
		  <div class="form group<?php echo e(($errors->has('sector')) ? $errors->first('sector') : ''); ?>">
		  <input type="text" name="sector" class="form-control" placeholder="Enter Sector">
		  <?php echo $errors->first('sector', '<p class="help-block">:message</p>'); ?>

		  </div>
		  <div class="form group<?php echo e(($errors->has('cellar')) ? $errors->first('cellar') : ''); ?>">
		  <input type="text" name="cellar" class="form-control" placeholder="Enter Cellar">
		  <?php echo $errors->first('cellar', '<p class="help-block">:message</p>'); ?>

		  </div>		  		  		  	
		  	  <input type="submit" class="button" value="save">  		  	  	  
			</form>
		</div>
		</div>
	</center>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>