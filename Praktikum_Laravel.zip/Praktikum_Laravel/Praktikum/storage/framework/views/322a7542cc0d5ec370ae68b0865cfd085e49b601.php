  
	<?php $__env->startSection('content'); ?>
	<div class="row" style="margin-top: 10rem;">
		<div class="col-md-12">
			<center><h1>Edit Data Client</h1></center>
		</div>
	</div>
	<center>
	<div class="container">
	<div class="row">
		<form class="form1" action="<?php echo e(route('person.update', $person->id)); ?>" method="post">
		<input type="hidden" name="_method" value="PATCH">
		<?php echo e(csrf_field()); ?>

		  <div class="form group<?php echo e(($errors->has('image')) ? $errors->first('image') : ''); ?>">
		  <input type="file" name="image" placeholder="Enter Image">
		  <?php echo $errors->first('image', '<p class="help-block">:message</p>'); ?>

		  </div>	
		  <div class="form group<?php echo e(($errors->has('fullnames')) ? $errors->first('fullnames') : ''); ?>">
		  <input type="text" name="fullnames" class="form-control" placeholder="Enter Fullname" value="<?php echo e($person->fullnames); ?>">
		  <?php echo $errors->first('fullnames', '<p class="help-block">:message</p>'); ?>

		  </div>	
		  <div class="form group<?php echo e(($errors->has('Sex')) ? $errors->first('Sex') : ''); ?>">
		  <input type="text" name="sex" class="form-control" placeholder="Enter Sex" value="<?php echo e($person->sex); ?>">
		  <?php echo $errors->first('sex', '<p class="help-block">:message</p>'); ?>

		  </div>	
		  <div class="form group<?php echo e(($errors->has('identitycard')) ? $errors->first('identitycard') : ''); ?>">
		  <input type="text" name="identitycard" class="form-control" placeholder="Enter Identity Card NR" value="<?php echo e($person->identitycard); ?>">
		  <?php echo $errors->first('identitycard', '<p class="help-block">:message</p>'); ?>

		  </div>
		  <div class="form group<?php echo e(($errors->has('birthdate')) ? $errors->first('birthdate') : ''); ?>">
		  <input type="text" name="birthdate" class="form-control" placeholder="Enter BirthDate" value="<?php echo e($person->birthdate); ?>">
		  <?php echo $errors->first('birthdate', '<p class="help-block">:message</p>'); ?>

		  </div>	
		  <div class="form group<?php echo e(($errors->has('province')) ? $errors->first('province') : ''); ?>">
		  <input type="text" name="province" class="form-control" placeholder="Enter Province" value="<?php echo e($person->province); ?>">
		  <?php echo $errors->first('province', '<p class="help-block">:message</p>'); ?>

		  </div>
		  <div class="form group<?php echo e(($errors->has('district')) ? $errors->first('district') : ''); ?>">
		  <input type="text" name="district" class="form-control" placeholder="Enter District" value="<?php echo e($person->district); ?>">
		  <?php echo $errors->first('district', '<p class="help-block">:message</p>'); ?>

		  </div>
		  <div class="form group<?php echo e(($errors->has('sector')) ? $errors->first('sector') : ''); ?>">
		  <input type="text" name="sector" class="form-control" placeholder="Enter Sector" value="<?php echo e($person->sector); ?>">
		  <?php echo $errors->first('sector', '<p class="help-block">:message</p>'); ?>

		  </div>
		  <div class="form group<?php echo e(($errors->has('cellar')) ? $errors->first('cellar') : ''); ?>">
		  <input type="text" name="cellar" class="form-control" placeholder="Enter Cellar" value="<?php echo e($person->cellar); ?>">
		  <?php echo $errors->first('cellar', '<p class="help-block">:message</p>'); ?>

		  </div>		  		  		  	
		  	  <input type="submit" class="button" value="save" style="color: blue; font-weight: bold; font-size: 2rem;">	  	  	  		
			</form>
		</div>
	</div>
	</center>	
<?php $__env->stopSection(); ?>	
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>