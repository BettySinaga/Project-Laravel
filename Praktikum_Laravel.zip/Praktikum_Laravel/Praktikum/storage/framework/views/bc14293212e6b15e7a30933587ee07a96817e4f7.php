	
	
	<?php $__env->startSection('content'); ?>
	<div class="row" style="margin-top: 10rem;">
		<div class="col-md-12">
			<center><h1>Client</h1></center>
		</div>
	</div>
	<div class="row">
	<form class="navbar-form navbar-left" role="search" method="get">
		<div class="input-group custom-search-form">
			<input type="text" name="search" class="form-control" placeholder="Search...">
			<span class="input-group-btn">
				<button type="submit" class="btn btn-default" style="background-color: grey; color: white;">
				search
				</button>
			</span>
		</div>

	</form>	
	   <table class="table table-responsive">
		<tr>
		  <th>No</th>
		  <th>image</th>
		  <th>Full names</th>
		  <th>Sex</th>
		  <th>Identity Card NR</th>
		  <th>Birth Date</th>
		  <th>Province</th>
		  <th>District</th>
		  <th>Sector</th>
		  <th>Cellar</th>
		  <th>Action</th>
		</tr>
		<a href="<?php echo e(route('person.create')); ?>" class="btn btn-info pull-right">Create New Client</a>		
		<?php $id=1;?>
	<?php $__currentLoopData = $persons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $person): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
		<tr>
		  <td><?php echo e($id); ?></td>
		  <td><img width="50" height="50" src="<?php echo e("image/".$person->image); ?>"></td>
		  <td><?php echo e($person->fullnames); ?></td>
		  <td><?php echo e($person->sex); ?></td>
		  <td><?php echo e($person->identitycard); ?></td>
		  <td><?php echo e($person->birthdate); ?></td>
		  <td><?php echo e($person->province); ?></td>
		  <td><?php echo e($person->district); ?></td>
		  <td><?php echo e($person->sector); ?></td>
		  <td><?php echo e($person->cellar); ?></td>
		  <td>
		  	<form class="" action="<?php echo e(route('person.destroy', $person->id)); ?>" method="post">
		  	  <input type="hidden" name="_method" value="delete">
		  	  <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
		  	  <a href="<?php echo e(route('person.edit', $person->id)); ?>" class="btn btn-primary">Edit</a>
		  	  <input type="submit" class="btn btn-danger" onclick="return confirm('Are you sure to delete this data?');" name="name" value="delete">
		  	</form>
		  </td>
		</tr>
		<?php $id++; ?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
		</table>
	</div>
	<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>